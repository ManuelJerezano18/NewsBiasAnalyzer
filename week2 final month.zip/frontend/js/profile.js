import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-app.js";
import { getAuth, onAuthStateChanged, signOut } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-auth.js";
import { getFirestore, doc, getDoc, setDoc, collection, getDocs, deleteDoc } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-firestore.js";
import { query, orderBy } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBnjBn6sTwnqDjrMXdgmFZ2dugrL5OVLTI",
    authDomain: "news-bias-analyzer.firebaseapp.com",
    projectId: "news-bias-analyzer",
    storageBucket: "news-bias-analyzer.appspot.com",
    messagingSenderId: "661563307465",
    appId: "1:661563307465:web:648bdabecbcf57b0d96418",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", () => {
    const elements = {
        articleHistoryBody: document.getElementById("article-history-body"),
        userName: document.getElementById("user-name"),
        userEmail: document.getElementById("user-email"),
        userPhone: document.getElementById("user-phone"),
        userWebsite: document.getElementById("user-website"),
        userBirthdate: document.getElementById("user-birthdate"),
        profilePictureInput: document.getElementById("profile-picture-input"),
        profilePictureImg: document.getElementById("profile-picture-img"),
        editProfileButton: document.getElementById("edit-profile-button"),
        editProfileForm: document.getElementById("edit-profile-form"),
        saveProfileButton: document.getElementById("save-profile-button"),
    };

    /**
     * Add click-to-upload functionality to the profile picture
     */
    elements.profilePictureImg.addEventListener("click", () => {
        elements.profilePictureInput.click(); // Trigger the file input dialog
    });

    /**
     * Save profile picture to Firestore and update the UI.
     */
    elements.profilePictureInput.addEventListener("change", async (event) => {
        const file = event.target.files[0];
        if (file) {
            const reader = new FileReader();
            reader.onload = async () => {
                const imageDataUrl = reader.result;
                const user = auth.currentUser;

                if (user) {
                    await updateUserDocument(user.uid, { profilePicture: imageDataUrl });
                    elements.profilePictureImg.src = imageDataUrl;
                }
            };
            reader.readAsDataURL(file);
        }
    });

    /**
     * Toggle Edit Profile form visibility
     */
    elements.editProfileButton.addEventListener("click", () => {
        elements.editProfileForm.style.display = "block";
        elements.editProfileButton.style.display = "none";
    });

    /**
     * Update or create a Firestore user document with new data.
     */
    async function updateUserDocument(userId, data) {
        try {
            const userDocRef = doc(db, `Users/${userId}`);
            await setDoc(userDocRef, data, { merge: true });
        } catch (error) {
            console.error("Error updating user document:", error);
        }
    }

    /**
     * Fetch and display the user's article history.
     */
    async function fetchArticleHistory(userId) {
        try {
            const userArticlesRef = collection(db, `Users/${userId}/Articles`);
            const querySnapshot = await getDocs(query(userArticlesRef, orderBy("submission_date", "desc")));
            elements.articleHistoryBody.innerHTML = "";

            if (querySnapshot.empty) {
                elements.articleHistoryBody.innerHTML = `
                    <tr>
                        <td colspan="6" style="text-align: center;">No articles submitted yet.</td>
                    </tr>`;
            } else {
                querySnapshot.forEach((doc) => {
                    const data = doc.data();
                    const row = `
                        <tr id="article-${doc.id}">
                            <td>${data.article_title || "Untitled"}</td>
                            <td><a href="${data.article_url}" target="_blank">${new URL(data.article_url).hostname}</a></td>
                            <td>${data.category || "N/A"}</td>
                            <td>${data.submission_date?.toDate().toLocaleDateString() || "N/A"}</td>
                            <td>${data.bias_score !== undefined ? data.bias_score : "N/A"}</td>
                            <td><button class="delete-btn" data-id="${doc.id}">Delete</button></td>
                        </tr>`;
                    elements.articleHistoryBody.innerHTML += row;
                });

                document.querySelectorAll(".delete-btn").forEach((button) => {
                    button.addEventListener("click", async (event) => {
                        const articleId = event.target.getAttribute("data-id");
                        await deleteArticle(userId, articleId);
                    });
                });
            }
        } catch (error) {
            console.error("Error fetching article history:", error);
            elements.articleHistoryBody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: red;">Failed to load article history.</td>
                </tr>`;
        }
    }

    /**
     * Delete an article from Firestore.
     */
    async function deleteArticle(userId, articleId) {
        try {
            await deleteDoc(doc(db, `Users/${userId}/Articles`, articleId));
            document.getElementById(`article-${articleId}`).remove();
        } catch (error) {
            console.error(`Error deleting article ${articleId}:`, error);
        }
    }

    /**
     * Save user profile details.
     */
    elements.saveProfileButton.addEventListener("click", async () => {
        const name = document.getElementById("edit-name").value;
        const phone = document.getElementById("edit-phone").value;
        const website = document.getElementById("edit-website").value;
        const birthdate = document.getElementById("edit-birthdate").value;

        const user = auth.currentUser;
        if (user) {
            await updateUserDocument(user.uid, { name, phone, website, birthdate });
            elements.userName.textContent = name || "User Name";
            elements.userPhone.textContent = phone || "N/A";
            elements.userWebsite.textContent = website || "N/A";
            elements.userWebsite.href = website.startsWith("http") ? website : `https://${website}`;
            elements.userBirthdate.textContent = birthdate || "N/A";

            elements.editProfileForm.style.display = "none";
            elements.editProfileButton.style.display = "inline";
        }
    });

    /**
     * Handle authenticated user and load profile data.
     */
    onAuthStateChanged(auth, async (user) => {
        if (user) {
            elements.userName.textContent = user.displayName || "User";
            elements.userEmail.textContent = user.email;

            try {
                const userDocRef = doc(db, `Users/${user.uid}`);
                const userDoc = await getDoc(userDocRef);

                if (userDoc.exists()) {
                    const userData = userDoc.data();
                    elements.userName.textContent = userData.name || "User Name";
                    elements.userPhone.textContent = userData.phone || "N/A";
                    elements.userWebsite.textContent = userData.website || "N/A";
                    elements.userWebsite.href = userData.website || "#";
                    elements.userBirthdate.textContent = userData.birthdate || "N/A";
                    if (userData.profilePicture) {
                        elements.profilePictureImg.src = userData.profilePicture;
                    }
                } else {
                    await updateUserDocument(user.uid, {
                        name: "User Name",
                        email: user.email,
                        phone: "N/A",
                        website: "N/A",
                        birthdate: "N/A",
                        profilePicture: "",
                    });
                }

                await fetchArticleHistory(user.uid);
            } catch (error) {
                console.error("Error handling user data:", error);
            }
        } else {
            window.location.href = "signin.html";
        }
    });
});
