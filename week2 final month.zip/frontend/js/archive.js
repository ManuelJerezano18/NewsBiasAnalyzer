import { initializeApp } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-app.js";
import { getAuth, onAuthStateChanged } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-auth.js";
import { getFirestore, collection, getDocs, query, orderBy } from "https://www.gstatic.com/firebasejs/10.14.0/firebase-firestore.js";

// Firebase configuration
const firebaseConfig = {
    apiKey: "AIzaSyBnjBn6sTwnqDjrMXdgmFZ2dugrL5OVLTI",
    authDomain: "news-bias-analyzer.firebaseapp.com",
    projectId: "news-bias-analyzer",
    storageBucket: "news-bias-analyzer.appspot.com",
    messagingSenderId: "661563307465",
    appId: "1:661563307465:web:648bdabecbcf57b0d96418",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

document.addEventListener("DOMContentLoaded", () => {
    const articleHistoryBody = document.getElementById("article-history-body");

    /**
     * Fetch user's article history and display it in the archives table
     */
    async function fetchUserArticles(userId) {
        try {
            const articlesRef = collection(db, `Users/${userId}/Articles`);
            const querySnapshot = await getDocs(query(articlesRef, orderBy("submission_date", "desc")));

            articleHistoryBody.innerHTML = ""; // Clear table before populating

            if (querySnapshot.empty) {
                articleHistoryBody.innerHTML = `
                    <tr>
                        <td colspan="6" style="text-align: center;">No articles submitted yet.</td>
                    </tr>`;
            } else {
                querySnapshot.forEach((doc) => {
                    const data = doc.data();
                    const row = `
                        <tr>
                            <td>${data.article_title || "Untitled"}</td>
                            <td><a href="${data.article_url}" target="_blank">${new URL(data.article_url).hostname}</a></td>
                            <td>${data.category || "N/A"}</td>
                            <td>${data.submission_date?.toDate().toLocaleDateString() || "N/A"}</td>
                            <td>${data.bias_score !== undefined ? data.bias_score : "N/A"}</td>
                            <td><button class="delete-btn" disabled>Delete</button></td>
                        </tr>`;
                    articleHistoryBody.innerHTML += row;
                });
            }
        } catch (error) {
            console.error("Error fetching user articles:", error);
            articleHistoryBody.innerHTML = `
                <tr>
                    <td colspan="6" style="text-align: center; color: red;">Failed to load articles.</td>
                </tr>`;
        }
    }

    // Authentication Check
    onAuthStateChanged(auth, (user) => {
        if (user) {
            fetchUserArticles(user.uid);
        } else {
            window.location.href = "signin.html";
        }
    });
});
