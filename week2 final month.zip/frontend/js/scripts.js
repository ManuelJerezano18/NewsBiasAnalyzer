
// Make sure the DOM is fully loaded before executing the rest of the code
document.addEventListener('DOMContentLoaded', function() {
    console.log("Page loaded successfully.");
});

// Import Firebase initialization and form handling from their respective modules
import { initializeFirebase } from './firebase.js';
import { handleFormSubmission } from './form_handler.js';

// Initialize Firebase and set up form handling
initializeFirebase(); // This sets up your Firebase app and Firestore
handleFormSubmission(); // This sets up the event listener for form submission

document.addEventListener("DOMContentLoaded", function() {
    // Animate the header after a brief delay to ensure DOM is fully loaded
    setTimeout(function() {
      document.querySelector('header').classList.add('animate');
    }, 100); // Adjust the delay as needed
  });

  document.addEventListener("DOMContentLoaded", function () {
    const animationContainer = document.getElementById("lottie-animation");
    lottie.loadAnimation({
        container: animationContainer, // HTML element to render the animation
        renderer: "svg",
        loop: true,
        autoplay: true,
        path: "Icons/Main Scene.json", // Path to your Lottie JSON file
    });
});

    document.addEventListener("DOMContentLoaded", function () {
    const container = document.getElementById("page-container");
    container.classList.add("fade-in");

    // Attach click event to all navigation links
    document.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', function(event) {
            const href = this.getAttribute('href');
            if (href && !href.startsWith('#')) { // Prevent default for anchor links
                event.preventDefault();

                // Add fade-out effect
                document.body.classList.add("fade-out");
                
                // Navigate after the animation finishes
                setTimeout(() => {
                    window.location.href = href;
                }, 500); // Match animation duration
            }
        });
    });
});

